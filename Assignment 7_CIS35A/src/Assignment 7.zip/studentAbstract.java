public abstract class studentAbstract implements stu{
	Student [] ArrayStudentObject;
	public abstract void readStat();
	public abstract void readScores();
	public abstract int getSID();
	public abstract void findlow(Student [] ArrayStudentObject);
	public abstract void findhigh(Student [] ArrayStudentObject);
	public abstract void findavg(Student [] ArrayStudentObject);
	

}
