//read stat and read scores 
public interface stu {
	public void readStat();
	public void readScores();
	public int getSID();
	public void findlow(Student [] ArrayStudentObject);

}
