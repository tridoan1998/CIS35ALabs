Name: Tri Doan
Class and Section: CIS 35A Monday and Wednesday 6:00pm class / in class 
Assignment 5
Due Date: 03/06/2019
Date Submitted: 03/06/2019

Test runs and class diagram included.

Instruction: 
Write a program to perform statistical analysis of scores for a class of students.
The program should print the lowest and highest scores for each quiz.
Read Student data from a text file.
Compute High, Low and Average for each quiz.
Print the Student data and display statistical information.
