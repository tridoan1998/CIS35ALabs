Name: Tri Doan
Class and Section: CIS 35A Monday and Wednesday 6:00pm class / in class 
Assignment 7
Due Date: 03/24/2019
Date Submitted: 03/24/2019

Test runs and class diagram included.

Instruction: 
Create and implement an interface to:
Print student statistics.
Print scores for a given student id.
implement the Debug flag globally.
use Abstract class 